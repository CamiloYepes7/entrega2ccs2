package App.service.interfaces;

import app.dto.UserDto;

public interface GuestService {
    public void createGuest( ) throws Exception;
public void becomeApartner() throws Exception;
    public void deleteGuest( ) throws Exception;    
}

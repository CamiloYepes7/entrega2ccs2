package app.controller;

public interface ControllerInterface {
    public void session() throws Exception;
}
